import React, { useEffect, useState } from "react";
import axios from "axios";
import { Typography, Button, Paper, Divider, List, ListItem, ListItemText, CircularProgress } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import "./HistoryPage.css";

const HistoryPage = () => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Function to fetch documents from the backend
  const fetchDocuments = async () => {
    try {
      // Use auth.currentUser?.email for the username in the URL
      const response = await axios.get(`http://127.0.0.1:5000/view-history/${auth.currentUser?.email}`);
      if (response.data.status === "success") {
        setDocuments(response.data.history); // Adjust based on your backend response
      } else {
        alert("Failed to fetch documents.");
      }
    } catch (error) {
      console.error("Error fetching documents:", error);
      alert("An error occurred while fetching documents.");
    } finally {
      setLoading(false);
    }
  };
  

  useEffect(() => {
    fetchDocuments();
  }, []);

  // Group documents by date
  const groupDocumentsByDate = () => {
    return documents.reduce((acc, document) => {
      const date = document.date.split("T")[0]; // Assuming date is in 'YYYY-MM-DD' format
      if (!acc[date]) acc[date] = [];
      acc[date].push(document);
      return acc;
    }, {});
  };

  const groupedDocuments = groupDocumentsByDate();

  return (
    <div className="history-page">
      <header className="header">
        <Typography variant="h4" align="center" style={{ marginBottom: "20px" }}>
          Document History
        </Typography>
      </header>

      <div className="documents-container">
        {loading ? (
          <div className="loading-container">
            <CircularProgress />
            <Typography variant="body1" style={{ marginTop: "10px" }}>
              Loading documents...
            </Typography>
          </div>
        ) : (
          <div className="documents-list">
            {Object.keys(groupedDocuments).map((date) => (
              <div key={date} className="date-group">
                <Typography variant="h6" style={{ marginTop: "20px", color: "#8a5e3b" }}>
                  {date}
                </Typography>
                <List>
                  {groupedDocuments[date].map((doc, index) => (
                    <Paper key={index} elevation={3} style={{ marginBottom: "10px", padding: "10px" }}>
                      <ListItem button onClick={() => navigate(`/document/${doc.id}`)}>
                        <ListItemText primary={doc.title} secondary={doc.description} />
                      </ListItem>
                    </Paper>
                  ))}
                </List>
                <Divider />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPage;
